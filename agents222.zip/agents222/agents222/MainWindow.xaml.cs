﻿using agents222.DB;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace agents222
{
    public class ItemSort
    {
        public string DisplayName { get; set; }
        public string PropertyName { get; set; }
        public bool Ascending { get; set; }
    }
    public partial class MainWindow : Window
    {
        public static Entities Connection = new Entities();
        public static ObservableCollection<Agent> Agents { get; set; }
        public static ObservableCollection<AgentType> AgentType { get; set; }
        public static ObservableCollection<ProductSale> ProductSale { get; set; }
        public ObservableCollection<ItemSort> ItemSorts { get; set; } = new ObservableCollection<ItemSort>()
        {
            new ItemSort() { DisplayName = "По наименованию А-Я", PropertyName = "AgentName", Ascending = true },
            new ItemSort() { DisplayName = "По наименованию Я-А", PropertyName = "AgentName", Ascending = false },
            new ItemSort() { DisplayName = "Размер скидки по возрастанию", PropertyName = "in_stock", Ascending = true },
            new ItemSort() { DisplayName = "Размер скидки по убыванию", PropertyName = "in_stock", Ascending = false },
            new ItemSort() { DisplayName = "Приоритет по возрастанию ", PropertyName = "Priority", Ascending = true },
            new ItemSort() { DisplayName = "Приоритет по убыванию ", PropertyName = "Priority", Ascending = false }
        };

        public MainWindow()
        {
            InitializeComponent();
            Agents = new ObservableCollection<Agent>(Connection.Agent.ToList());
            AgentType = new ObservableCollection<AgentType>(Connection.AgentType.ToList());
            ProductSale = new ObservableCollection<ProductSale>(Connection.ProductSale.ToList());
            AgentType.Insert(0, new AgentType() { AgentType1 = "Все типы" });
            DataContext = this;
        }

        private void CbSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var item = cbSort.SelectedItem as ItemSort;
            var view = CollectionViewSource.GetDefaultView(lvAgent.ItemsSource);
            view.SortDescriptions.Clear();
            view.SortDescriptions.Add(new SortDescription(item.PropertyName, item.Ascending ? ListSortDirection.Ascending : ListSortDirection.Descending));
        }

        private void CbFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            AgentType agentType = cbFilter.SelectedItem as AgentType;
            var view = CollectionViewSource.GetDefaultView(lvAgent.ItemsSource);
            if (cbFilter.SelectedIndex == 0)
            {
                view.Filter = null;
            }
            else
            {
                view.Filter = new Predicate<object>(o => { return (o as Agent).AgentType == agentType.AgentType1; });
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            CreateAgent createAgent = new CreateAgent();
            createAgent.Show();
        }

        private void lvAgent_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedAgent = lvAgent.SelectedItem as Agent;
            new EditAgent(selectedAgent).Show();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (SearchAgent.Text == "Введите для поиска") return;
            var agentSearch = Connection.Agent.Where(x => x.AgentName.Contains(SearchAgent.Text)).ToList();
            if (agentSearch == null) return;
            Agents = new ObservableCollection<Agent>(agentSearch);
            lvAgent.ItemsSource = agentSearch;
        }
        public void Search(string substring)
        {
            ICollectionView view = CollectionViewSource.GetDefaultView(lvAgent.ItemsSource);
            if (view == null) return;
            int viewCounter = 0;
            view.Filter = new Predicate<object>(obj =>
            {
                bool isView = ((DB.Agent)obj).AgentName.ToLower().Contains(substring.ToLower());
                if (isView) viewCounter++;
                return isView;
            });
        }
        private void SearchAgent_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (SearchAgent.Text == "Введите для поиска") SearchAgent.Clear();
        }

        private void SearchAgent_LostFocus(object sender, RoutedEventArgs e)
        {
            if (SearchAgent.Text == "") SearchAgent.Text = "Введите для поиска";
        }
    }
}