﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace agents222
{
    public partial class CreateAgent : Window
    {
        public DB.Agent NewAgent { get; set; }
        public CreateAgent()
        {
            InitializeComponent();
            cbAgentType.SetBinding(ComboBox.ItemsSourceProperty, new Binding() { Source = MainWindow.AgentType });
            NewAgent = new DB.Agent();
            DataContext = this;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog
            {
                Multiselect = false,
                InitialDirectory = new FileInfo(AppDomain.CurrentDomain.BaseDirectory).Directory.Parent.Parent + "\\images"
            };
            if (dialog.ShowDialog().Value == true)
            {
                NewAgent.AgentLogo = "images/" + dialog.SafeFileName;
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MainWindow.Connection.Agent.Add(NewAgent);
            int result = MainWindow.Connection.SaveChanges();
            if (result == 1)
            {
                MainWindow.Agents.Add(NewAgent);
                NewAgent = new DB.Agent();
                spAgent.GetBindingExpression(DataContextProperty).UpdateTarget();
                MessageBox.Show("Агент успешно добавлен");
            }
        }
    }
}