﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace agents222
{
    public partial class EditAgent : Window
    {
        public DB.Agent Agent { get; set; }
        public EditAgent(DB.Agent agent)
        {
            InitializeComponent();
            Agent = agent;
            cbAgentType.SetBinding(ComboBox.ItemsSourceProperty, new Binding() { Source = MainWindow.AgentType });
            DataContext = this;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.Connection.SaveChanges();
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog
            {
                Multiselect = false,
                InitialDirectory = new FileInfo(AppDomain.CurrentDomain.BaseDirectory).Directory.Parent.Parent + ""
            };
            if (dialog.ShowDialog().Value == true)
            {
                Agent.AgentLogo = "images/" + dialog.SafeFileName;
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            MainWindow.Agents.Remove(Agent);
            MainWindow.Connection.Agent.Remove(Agent);
            MainWindow.Connection.SaveChanges();
            Close();
        }
    }
}
